
    document.getElementById("myButton").onclick = function () {
        location.href = "/MainProject/src/main/webapp/WEB-INF/view/medicaldata.jsp";
    };
